<?php
// The file has been moved in iTop 2.2.0+ (revision 3803)
// Preserve backward compatibility with some external tools (Cf. toolkit)
require_once(APPROOT.'core/oql/expression.class.inc.php');
